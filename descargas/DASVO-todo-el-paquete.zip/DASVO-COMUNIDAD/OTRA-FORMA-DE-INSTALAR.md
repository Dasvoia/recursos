# Otra forma de instalar

## Léelo solo si la de EMPIEZA-AQUI no te funcionó

La forma normal son dos líneas y se acabó. Esta es el plan B: instalar desde la
carpeta que ya descargaste, sin bajar nada de internet.

Es un poquito más larga porque hay que decirle a Claude Code **dónde** quedó la
carpeta en tu computador. Nada más.

---

## PASO 1 — Encuentra la carpeta

Dentro de lo que descargaste hay una carpeta que se llama **plugin**.

Está así:

```
DASVO-COMUNIDAD
   EMPIEZA-AQUI
   guias-pdf
   panel.html
   plugin          <-- esta
```

---

## PASO 2 — Consigue la dirección de esa carpeta

Necesitas la dirección exacta. Algo como
`/Users/TU-NOMBRE/Downloads/DASVO-COMUNIDAD/plugin`.

Escoge la forma más fácil para ti:

### La forma fácil: que la busque Claude Code

Abre Claude Code y pega esto:

```
Busca en mi computador una carpeta llamada "plugin" que esté dentro de otra
llamada "DASVO-COMUNIDAD". Mira en Descargas, Downloads, Escritorio y Desktop.
Cuando la encuentres, escríbeme la ruta completa en una sola línea y nada más.
```

Él te la escribe. Cópiala.

### La forma manual: arrastrar

- **En Mac:** abre la Terminal, escribe `cd ` (con el espacio), arrastra la
  carpeta `plugin` hasta la ventana y suéltala. Se escribe sola la dirección.
- **En Windows:** entra a la carpeta `plugin`, haz clic en la barra de arriba
  donde dice la ruta, y cópiala.

---

## PASO 3 — Instálala

En Claude Code, pega esta línea, **pero cambia** `PEGA-AQUI-LA-DIRECCION` por lo
que copiaste:

```
/plugin marketplace add PEGA-AQUI-LA-DIRECCION
```

Enter.

Después estas dos, tal cual:

```
/plugin install dasvo@dasvo-ia-builders
```

```
/reload-plugins
```

---

## PASO 4 — Comprueba

Escribe una barra:

```
/
```

Deben salir trece que empiezan con **dasvo**. Si salen, terminaste.

---

## Si sigue sin funcionar

No lo intentes diez veces. Publica en la comunidad:

1. En qué paso te quedaste.
2. El texto completo que te salió, copiado y pegado.
3. Si estás en Mac o en Windows.

Con eso se resuelve rápido. Sin eso, nadie te puede ayudar.
