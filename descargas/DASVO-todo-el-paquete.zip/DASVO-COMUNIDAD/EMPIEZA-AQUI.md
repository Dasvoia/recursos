# EMPIEZA AQUÍ

## Léeme completo. Son 4 minutos.

> **Todo esto también está en línea, siempre actualizado:**
> https://dasvo-recursos.vercel.app

---

## Qué vas a tener al final de esta hoja

Trece herramientas dentro de tu computador que construyen, por ti, sistemas de
reservas para negocios locales. Tú no escribes código. Tú das órdenes.

---

## Antes de nada: dos cosas que necesitas

**1. Claude Code instalado en tu computador.**

Claude Code es un programa. Se escribe en él como se escribe en WhatsApp, y él
hace el trabajo en tu computador.

Se descarga aquí: **claude.com/code**

**2. Una cuenta de pago de Claude.**

Sirve el plan Pro, Max, Team o Enterprise. **El plan gratis NO sirve.** Si
intentas con el gratis, no va a funcionar y vas a creer que hiciste algo mal.
No hiciste nada mal: es que no está incluido.

Si no tienes ninguna de las dos, para aquí. Consíguelas y vuelve.

---

## PASO 1 — Abre Claude Code

Ábrelo como abres cualquier programa.

Vas a ver una pantalla con un espacio para escribir abajo. Eso es todo lo que
necesitas.

**¿Cómo sé que voy bien?** Ves un cursor parpadeando esperando que escribas.

---

## PASO 2 — Copia esta línea y pégala ahí

```
/plugin marketplace add Dasvoia/dasvo-ia-builders
```

Le das Enter.

Espera unos segundos. Va a decir algo como "Successfully added marketplace".

**¿Qué acabas de hacer?** Le dijiste a Claude Code dónde queda la caja de
herramientas. Todavía no la abriste.

**¿Cómo sé que voy bien?** Aparece la palabra *Successfully* o un chulito verde.

---

## PASO 3 — Copia esta otra línea y pégala

```
/plugin install dasvo@dasvo-ia-builders
```

Enter otra vez.

Te va a preguntar dónde instalarlo. Escoge la opción que dice **user**. Esa
significa "en todos mis proyectos", que es lo que quieres.

**¿Qué acabas de hacer?** Abriste la caja. Las trece herramientas ya están
adentro de tu computador.

---

## PASO 4 — Despierta las herramientas

```
/reload-plugins
```

Enter.

---

## PASO 5 — Comprueba que sí quedaron

Escribe una barra inclinada. Solo eso:

```
/
```

Se despliega una lista. Busca las que empiezan con **dasvo**. Deben ser doce:

```
/dasvo:setup-cuentas
/dasvo:sistema-de-citas
/dasvo:adaptar-a-nicho
/dasvo:ahorro-tokens
/dasvo:seguridad-web
/dasvo:arreglar-errores
/dasvo:publicar-online
/dasvo:conseguir-clientes
/dasvo:cerrar-venta
/dasvo:entregar-al-cliente
/dasvo:crear-skill
/dasvo:crear-subagente
```

**¿Las ves? Ya está. Terminaste la instalación.**

---

## Y ahora qué hago

Escribe esto y dale Enter:

```
/dasvo:setup-cuentas
```

Esa herramienta te lleva de la mano, un paso a la vez, a crear las tres cuentas
que necesitas. Te va a decir qué botón oprimir y en qué página. Tú solo
respondes y le dices "listo" cuando termines cada paso.

**No hagas nada más todavía. Solo eso.**

---

## Si algo se dañó

### "No me aparece el comando /plugin"

Tu Claude Code está viejo. Ciérralo, actualízalo desde claude.com/code y vuelve
a abrirlo.

### "Me dice que no encuentra el marketplace"

Revisa que copiaste la línea completa, sin que falte ni sobre nada. Ojo con los
espacios. Cópiala otra vez y pégala de nuevo.

### "Me pide iniciar sesión"

Normal. Es la primera vez. Inicia sesión con tu cuenta de Claude y sigue.

### "Salió un texto rojo largo"

Copia ese texto rojo completo, pégalo en la comunidad y dinos en qué paso
estabas. Alguien te responde. No lo intentes diez veces: se arregla en un
minuto si nos cuentas qué dice.

### "Escribí / y no salió ninguna dasvo"

Cierra Claude Code por completo. Ábrelo otra vez. Escribe `/` de nuevo. Si
sigue sin salir, repite el PASO 3.

---

## Palabras raras que vas a oír, en cristiano

| Palabra | Qué es, sin adornos |
|---|---|
| **Terminal** | Una ventana negra donde se escriben órdenes. Claude Code vive ahí. |
| **Skill** | Una herramienta. Un instructivo que le enseña a la IA a hacer una tarea completa. |
| **Plugin** | La caja donde vienen las trece herramientas juntas. |
| **Supabase** | Donde se guardan las citas de tus clientes. Como un Excel gigante en internet. |
| **GitHub** | Donde se guarda el código, con copia de seguridad. |
| **Vercel** | Lo que pone tu página en internet para que la gente entre. |
| **Llave (API key)** | Una contraseña larga que conecta dos servicios. Nunca se le muestra a nadie. |
| **Desplegar / publicar** | Subir tu página a internet para que tenga un link real. |
| **CLAUDE.md** | Un archivo de texto con las reglas del negocio. Es el cerebro del proyecto. |

---

## Lo único que tienes que hacer tú a mano

Las herramientas hacen casi todo. Tú solo tienes que:

1. **Crear tres cuentas** en Supabase, GitHub y Vercel. Correo y contraseña, ya.
2. **Copiar unas llaves** de esas páginas y pegarlas donde la herramienta te
   diga. Ella te dice el botón exacto.
3. **Decidir cosas del negocio**: qué servicios, qué horarios, qué precios.
4. **Hablarle a los clientes.** Eso no lo hace ninguna IA por ti.

Todo lo demás lo hace Claude Code.

---

## Qué más hay en esta carpeta

| Carpeta | Qué es |
|---|---|
| `guias-pdf/` | Cuatro guías. Empieza por el glosario si algo no te suena. |
| `panel.html` | Ábrelo con doble clic. Es el mapa de todo, con buscador. |
| `graficos/` | Las imágenes del método, por si quieres usarlas. |
| `plantillas/` | El archivo de reglas del consultorio del video, de ejemplo. |
| `plugin/` | La caja de herramientas, por si prefieres instalarla desde acá. |

---

## Una advertencia honesta

Los precios de Vercel y Supabase que verás en las guías se revisaron en julio
de 2026. **Míralos tú antes de cobrarle a un cliente.** Los cambian.

Los precios que enseñamos a cobrar son precios de mercado. No son una promesa
de que vas a ganar eso.
